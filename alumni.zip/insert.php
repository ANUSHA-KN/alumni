<?php
include "dbconfig.php";
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$password=$_POST['password'];
$confirmpassword=$_POST['confirmpassword'];
$workingstatus=$_POST['workingstatus'];
$experience=$_POST['experience'];
$sql="insert into alumni(firstname,lastname,email,password,confirmpassword,workingstatus,experience)values('$firstname','$lastname','$email','$password','$workingstatus','$experience')";
if(mysqli_ query($conn, $sql))
{
echo "Insert Successful";
echo '<script> alert("insert done")</script>';
header('refresh:1, url=losi.php');
}
else
   echo "failure";

mysqli_close($conn);
?>