<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login | By Code Info</title>
    <link rel="stylesheet" href="code.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="login-box">
      <h1>Login</h1>
      <form action="checklogin.php" method="post">
	  <table>
       <tr> 
			<td><label>Email</label></td>
			<td><input type="email" name="email" placeholder="" ></td>
	   </tr>
       <tr> 
			<td><label>Password</label></td>	
			<td><input type="password" name="password" placeholder="" /></td>
		</tr>
        <tr>
		<td><input type="submit" name="submit" value="Submit" /></td>
		</tr>
      <closeform></closeform>
    </table></form>
    <p class="para-2">
      Not have an account? <a href="losi.php">Sign Up Here</a>
	  </div>
    </p>
  </body>
</html>