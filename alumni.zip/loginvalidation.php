<?php
session_start();
require "dbconfig.php";
	
$email=$_POST['email'];
$password=$_POST['password'];

	
$sql="SELECT * FROM alumni where email = '$email' AND password = '$password'  ";
	
$result =mysqli_query($conn ,$sql);
$check = mysqli_fetch_array($result);
if(isset($check)){
	
    echo '<script>alert("Logged in successfully")</script>';
	$_SESSION['email']=$email;
	$sql1="INSERT INTO alumni(email,password)
	VALUES('$email','$password')";
	$result1=mysqli_query($conn,$sql1);
	if($result1)
	{
		header('refresh:1;url=newlo.php');
	}
	else{
		echo"error";
	}
}
else{
	echo '<script>alert("INVALID LOGIN !!!")</script>';
		
	header('refresh:3;url=loginvalidation.html');
}


mysqli_close($conn);
?>