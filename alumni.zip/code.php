*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body{
    position: relative;
    width: 100%;
    min-height: 100vh;
    height: auto;
    display: flex;
    justify-content: center;
    align-items: center;
    background: url('../img/bg.png');
    background-size: cover;
    background-position: center;
    font-family: 'roboto', sans-serif;
}

.container{
    position: relative;
    width: 90%;
    height: 87vh;
    border: 5px solid #fff;
    display: flex;
    justify-content: center;
    align-items: center;
}

.logout{
    position: absolute;
    top: 10px;
    right: 0;
    padding: 10px 20px;
    text-transform: capitalize;
    font-size: 16px;
    color: #fff;
    background: none;
    text-decoration: underline;
    cursor: pointer;
    outline: none;
    border: none;
}

.greeting{
    font-family: 'dosis';
    font-size: 100px;
    color: #fff;
    font-weight: 800;
    text-transform: capitalize;
}