
<?php
include "dbconfig.php";
$email=$_POST['email'];
$password=$_POST['password'];
$sql="select * from alumni where  email='$email' and password='$password'";
if(mysqli_query($conn, $sql))
{
echo "Login Successful";
header('refresh:10,url=profile.php');
}
else
   echo "invalld login";

mysqli_close($conn);
?>
