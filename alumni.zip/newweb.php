<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="old.css">
  </head>

  <body>
    <section class="hero-section">

      <nav class="navbar">
        <h2>Alumni University</h2>
        <ul>
          <li><a href="home.php">Home</a></li>
          <li><a href="contact.html">Contact</a></li>
          <li><a href="about.html">About</a></li>
        </ul>
      </nav>
      <div class="hero-text">
        <h2> Alumni Associated For Life</h2>
        <p>Build Yourself With Technology</p>
        <a href="newlo.php">Login here</a><div>
      </div>
    </section>
  </body>
</html>
